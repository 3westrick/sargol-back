from django.contrib import admin
from value.models import Value

# Register your models here.
admin.site.register(Value)