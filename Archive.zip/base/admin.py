from django.contrib import admin
from base.models import User

# Register your models here.
admin.site.register(User)