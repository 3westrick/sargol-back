from django.urls import path, include
from . import views
urlpatterns = [
    path("", views.ValueListView.as_view()),
    path("create/", views.ValueCreateView.as_view()),
    path("<int:pk>/", views.ValueRetriveView.as_view()),
    path("edit/<int:pk>/", views.ValueUpdateView.as_view()),
    path("delete/<int:pk>/", views.ValueDeleteView.as_view()),
]