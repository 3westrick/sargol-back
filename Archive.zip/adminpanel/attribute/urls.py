
from django.urls import path, include
from . import views
urlpatterns = [
    path("", views.AttributeListView.as_view()),
    path("create/", views.AttributeCreateView.as_view()),
    path("<int:pk>/", views.AttributeRetriveView.as_view()),
    path("edit/<int:pk>/", views.AttributeUpdateView.as_view()),
    path("delete/<int:pk>/", views.AttributeDeleteView.as_view()),
]