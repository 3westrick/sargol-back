from django.contrib import admin
from attribute.models import Attribute
# Register your models here.

admin.site.register(Attribute)
